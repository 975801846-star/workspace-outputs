// 生词主动回忆 — 前端逻辑
let currentPage = 0;       // 当前页索引
let pages = [];            // 分页后的单词，pages[页][词]
let pageSize = 20;
let uploadedText = "";     // 上传课件的文本

// ---------- Tab 切换 ----------
document.querySelectorAll(".tab").forEach(t => {
  t.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach(x => x.classList.remove("active"));
    document.querySelectorAll(".panel").forEach(x => x.classList.remove("active"));
    t.classList.add("active");
    document.getElementById(t.dataset.tab).classList.add("active");
    if (t.dataset.tab === "notebook") loadNotebook();
    if (t.dataset.tab === "add") loadWords();
    if (t.dataset.tab === "settings") loadConfig();
  });
});

// ---------- 录词 ----------
document.getElementById("wordForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const body = {
    word: document.getElementById("fWord").value,
    note: document.getElementById("fNote").value,
    zh: document.getElementById("fZh").value,
    example: document.getElementById("fExample").value,
  };
  const r = await fetch("/api/words", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const res = await r.json();
  if (res.error) { alert(res.error); return; }
  document.getElementById("wordForm").reset();
  loadWords();
});

async function loadWords() {
  const r = await fetch("/api/words");
  const words = await r.json();
  const box = document.getElementById("wordList");
  box.innerHTML = words.map(w => `
    <div class="word-card">
      <span class="w">${esc(w.word)}</span>
      <span class="del" onclick="delWord(${w.id})">删除</span>
    </div>`).join("");
}

async function delWord(id) {
  if (!confirm("确定删除该单词？")) return;
  await fetch(`/api/words/${id}`, { method: "DELETE" });
  loadWords();
}

// ---------- 背词 ----------
document.getElementById("btnStart").addEventListener("click", startQuiz);

async function startQuiz() {
  const r = await fetch("/api/quiz/today");
  const data = await r.json();
  const words = data.words;
  if (words.length === 0) {
    alert("今天已经没有新词了🎉（或词库为空）");
    return;
  }
  const cfg = await (await fetch("/api/config")).json();
  pageSize = cfg.page_size || 20;
  // 分页
  pages = [];
  for (let i = 0; i < words.length; i += pageSize) {
    pages.push(words.slice(i, i + pageSize));
  }
  currentPage = 0;
  document.getElementById("recallInfo").textContent = `今日 ${words.length} 词 · 共 ${pages.length} 页`;
  renderPage();
}

function renderPage() {
  const page = pages[currentPage];
  if (!page) return;
  const box = document.getElementById("quizContainer");
  box.innerHTML = `
    <div class="quiz-page">
      <h4>第 ${currentPage + 1} / ${pages.length} 页</h4>
      ${page.map(w => `
        <div class="q-row">
          <div class="q-word">${esc(w.word)}</div>
          <textarea class="q-input" data-wid="${w.id}" placeholder="用英文写下你的理解..."></textarea>
        </div>`).join("")}
      <div class="quiz-actions">
        ${currentPage > 0 ? `<button class="primary" onclick="prevPage()">上一页</button>` : ""}
        <button class="primary" onclick="submitPage()">${currentPage < pages.length - 1 ? "提交并下一页 →" : "提交本页"}</button>
      </div>
    </div>`;
}

function prevPage() { currentPage--; renderPage(); }

async function submitPage() {
  const inputs = document.querySelectorAll(".q-input");
  const answers = [];
  inputs.forEach(inp => {
    answers.push({ word_id: parseInt(inp.dataset.wid), input: inp.value });
  });
  const r = await fetch("/api/quiz/submit", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ answers }),
  });
  const res = await r.json();
  showResults(res.results, () => {
    if (currentPage < pages.length - 1) {
      currentPage++;
      renderPage();
    } else {
      document.getElementById("quizContainer").innerHTML =
        `<div class="quiz-page"><p>🎉 今日学习完成！</p></div>`;
    }
  });
}

function showResults(results, afterClose) {
  const list = document.getElementById("resultList");
  list.innerHTML = results.map(r => `
    <div class="result-item ${r.verdict}">
      <div class="r-word">${esc(r.word)}
        ${r.verdict === "wrong" ? ' <span style="color:#e67e22">（理解错误）</span>' : ' <span style="color:#27ae60">（理解正确）</span>'}
      </div>
      <div class="r-input">你的释义：${markMisspell(r.user_input, r.misspell)}</div>
      <div>参考答案：${esc(r.note)}</div>
      ${r.advice ? `<div class="advice">💡 ${esc(r.advice)}</div>` : ""}
      <div style="margin-top:8px">
        <button class="link-btn" onclick="toggleZh(this,'${esc(r.zh)}')">显示中文</button>
        <button class="link-btn" onclick="toggleExample(this,'${esc(r.example)}')">例句</button>
        ${hasMisspell(r) ? `<button class="add-nb" title="加入拼写笔记本" onclick="addSpelling(${r.word_id})">+</button>` : ""}
      </div>
      <div class="show-zh">${esc(r.zh)}</div>
      <div class="show-example">${esc(r.example)}</div>
    </div>`).join("");
  document.getElementById("resultModal").classList.add("show");
  document.getElementById("btnCloseModal").onclick = () => {
    document.getElementById("resultModal").classList.remove("show");
    afterClose();
  };
}

function markMisspell(text, misspell) {
  if (!misspell || misspell.length === 0) return esc(text);
  let out = esc(text);
  misspell.forEach(m => {
    out = out.replace(new RegExp(escRegex(m), "gi"), `<span class="misspell">${m}</span>`);
  });
  return out;
}

function escRegex(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }

function hasMisspell(r) { return r.misspell && r.misspell.length > 0; }

function toggleZh(btn, zh) {
  const div = btn.closest(".result-item").querySelector(".show-zh");
  div.style.display = div.style.display === "block" ? "none" : "block";
  if (zh && div.innerHTML === "") div.innerHTML = esc(zh);
}
function toggleExample(btn, ex) {
  const div = btn.closest(".result-item").querySelector(".show-example");
  div.style.display = div.style.display === "block" ? "none" : "block";
  if (ex && div.innerHTML === "") div.innerHTML = esc(ex);
}

async function addSpelling(wordId) {
  await fetch("/api/notebook", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ word_id: wordId, type: "spelling" }),
  });
  alert("已加入拼写笔记本");
}

// ---------- 笔记本 ----------
async function loadNotebook() {
  const r = await fetch("/api/notebook");
  const items = await r.json();
  const sp = items.filter(i => i.type === "spelling");
  const un = items.filter(i => i.type === "understand");
  document.getElementById("nbSpelling").innerHTML = sp.length ? sp.map(nbItem).join("") : "<div class='muted'>暂无</div>";
  document.getElementById("nbUnderstand").innerHTML = un.length ? un.map(nbItem).join("") : "<div class='muted'>暂无</div>";
}

function nbItem(i) {
  return `<div class="nb-item">${esc(i.word)} <span class="nb-del" onclick="delNb(${i.nb_id})">删除</span></div>`;
}
async function delNb(id) {
  await fetch(`/api/notebook/${id}`, { method: "DELETE" });
  loadNotebook();
}

// ---------- 设置 ----------
async function loadConfig() {
  const cfg = await (await fetch("/api/config")).json();
  document.getElementById("cfgDaily").value = cfg.daily_limit || 20;
  document.getElementById("cfgPage").value = cfg.page_size || 20;
}
document.getElementById("btnSaveCfg").addEventListener("click", async () => {
  const body = {
    deepseek_api_key: document.getElementById("cfgKey").value || undefined,
    daily_limit: parseInt(document.getElementById("cfgDaily").value),
    page_size: parseInt(document.getElementById("cfgPage").value),
  };
  await fetch("/api/config", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  document.getElementById("cfgKey").value = "";
  alert("设置已保存");
});

// ---------- 课件上传 ----------
document.getElementById("fileUpload").addEventListener("change", async (e) => {
  const f = e.target.files[0];
  if (!f) return;
  const fd = new FormData();
  fd.append("file", f);
  const r = await fetch("/api/upload", { method: "POST", body: fd });
  const res = await r.json();
  if (res.ok) {
    uploadedText = res.text;
    document.getElementById("uploadMsg").textContent = `已上传 ${res.filename}`;
  } else {
    document.getElementById("uploadMsg").textContent = "上传失败";
  }
});

// ---------- 导出 ----------
document.getElementById("btnExport").addEventListener("click", () => {
  window.location.href = "/api/export";
});

// ---------- 工具 ----------
function esc(s) {
  if (s === null || s === undefined) return "";
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
