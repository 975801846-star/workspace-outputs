# -*- coding: utf-8 -*-
"""
学术生词主动回忆小程序 — Flask 后端
本地网页版，SQLite 数据库，DeepSeek API 判定
"""
import os
import json
import sqlite3
import random
from datetime import datetime, date
from flask import Flask, request, jsonify, render_template, send_from_directory
import requests

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "vocab.db")
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
CONFIG_PATH = os.path.join(BASE_DIR, "config.json")

os.makedirs(UPLOAD_DIR, exist_ok=True)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 20 * 1024 * 1024  # 20MB 上传限制


# ---------- 配置 ----------
def load_config():
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"deepseek_api_key": "", "daily_limit": 20, "page_size": 20}


def save_config(cfg):
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)


# ---------- 数据库 ----------
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    c = conn.cursor()
    # 单词表
    c.execute("""
        CREATE TABLE IF NOT EXISTS words (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            word TEXT NOT NULL UNIQUE,
            note TEXT NOT NULL DEFAULT '',      -- 同义/英文释义（必填栏）
            zh TEXT DEFAULT '',                 -- 中文翻译（可空）
            example TEXT DEFAULT '',            -- 例句
            created_at TEXT DEFAULT (datetime('now','localtime'))
        )
    """)
    # 学习/复习记录表（记录每天答对情况，用于"连续3天正确移出"）
    c.execute("""
        CREATE TABLE IF NOT EXISTS reviews (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            word_id INTEGER NOT NULL,
            review_date TEXT NOT NULL,          -- 自然日 YYYY-MM-DD
            result TEXT NOT NULL,               -- correct / spelling / wrong
            last_input TEXT DEFAULT '',         -- 安当时的输入
            created_at TEXT DEFAULT (datetime('now','localtime'))
        )
    """)
    # 笔记本表：type = 'spelling' 或 'understand'
    c.execute("""
        CREATE TABLE IF NOT EXISTS notebook (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            word_id INTEGER NOT NULL,
            type TEXT NOT NULL,                 -- spelling / understand
            added_at TEXT DEFAULT (datetime('now','localtime'))
        )
    """)
    # 每日已学记录（防止当天重复）
    c.execute("""
        CREATE TABLE IF NOT EXISTS daily_done (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            word_id INTEGER NOT NULL,
            done_date TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()


def today_str():
    return date.today().isoformat()


# ---------- 路由 ----------
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/config", methods=["GET", "POST"])
def api_config():
    if request.method == "GET":
        cfg = load_config()
        # 不把完整 key 回传前端，只回传是否已配置
        cfg["has_key"] = bool(cfg.get("deepseek_api_key"))
        cfg["deepseek_api_key"] = ""
        return jsonify(cfg)
    else:
        data = request.get_json()
        cfg = load_config()
        if data.get("deepseek_api_key"):
            cfg["deepseek_api_key"] = data["deepseek_api_key"]
        if data.get("daily_limit") is not None:
            cfg["daily_limit"] = int(data["daily_limit"])
        if data.get("page_size") is not None:
            cfg["page_size"] = int(data["page_size"])
        save_config(cfg)
        cfg["has_key"] = bool(cfg.get("deepseek_api_key"))
        cfg["deepseek_api_key"] = ""
        return jsonify(cfg)


# ---------- 单词录入 ----------
@app.route("/api/words", methods=["GET", "POST"])
def api_words():
    conn = get_db()
    if request.method == "GET":
        rows = conn.execute("SELECT * FROM words ORDER BY created_at DESC").fetchall()
        return jsonify([dict(r) for r in rows])
    else:
        data = request.get_json()
        word = (data.get("word") or "").strip()
        note = (data.get("note") or "").strip()
        zh = (data.get("zh") or "").strip()
        example = (data.get("example") or "").strip()
        if not word or not note:
            return jsonify({"error": "word 和 note 必填"}), 400
        try:
            conn.execute(
                "INSERT INTO words (word, note, zh, example) VALUES (?,?,?,?)",
                (word, note, zh, example),
            )
            conn.commit()
            return jsonify({"ok": True, "word": word})
        except sqlite3.IntegrityError:
            return jsonify({"error": f"单词 '{word}' 已存在"}), 400
        finally:
            conn.close()


@app.route("/api/words/<int:wid>", methods=["DELETE"])
def api_word_delete(wid):
    conn = get_db()
    conn.execute("DELETE FROM words WHERE id=?", (wid,))
    conn.execute("DELETE FROM reviews WHERE word_id=?", (wid,))
    conn.execute("DELETE FROM notebook WHERE word_id=?", (wid,))
    conn.execute("DELETE FROM daily_done WHERE word_id=?", (wid,))
    conn.commit()
    conn.close()
    return jsonify({"ok": True})


# ---------- 出题 ----------
@app.route("/api/quiz/today", methods=["GET"])
def api_quiz_today():
    """返回当天要学的单词列表（随机打乱、排除当天已学）"""
    conn = get_db()
    cfg = load_config()
    daily_limit = cfg.get("daily_limit", 20)
    t = today_str()
    # 排除当天已学
    rows = conn.execute("""
        SELECT * FROM words
        WHERE id NOT IN (SELECT word_id FROM daily_done WHERE done_date = ?)
        ORDER BY RANDOM()
    """, (t,)).fetchall()
    conn.close()
    words = [dict(r) for r in rows[:daily_limit]]
    return jsonify({"words": words, "total_today": len(words)})


# ---------- 提交一页答案 + AI 判定 ----------
@app.route("/api/quiz/submit", methods=["POST"])
def api_quiz_submit():
    data = request.get_json()
    answers = data.get("answers", [])  # [{word_id, input}]
    if not answers:
        return jsonify({"error": "无答案"}), 400

    cfg = load_config()
    api_key = cfg.get("deepseek_api_key", "")
    conn = get_db()
    t = today_str()
    results = []

    for a in answers:
        wid = a.get("word_id")
        user_input = (a.get("input") or "").strip()
        row = conn.execute("SELECT * FROM words WHERE id=?", (wid,)).fetchone()
        if not row:
            continue
        word_info = dict(row)

        # 记录当天已学
        conn.execute(
            "INSERT OR IGNORE INTO daily_done (word_id, done_date) VALUES (?,?)",
            (wid, t),
        )

        # AI 判定
        if api_key and user_input:
            ai = judge_with_ai(api_key, word_info, user_input)
        else:
            ai = {"verdict": "correct", "understand": True, "misspell": [], "advice": ""}

        verdict = ai.get("verdict", "correct")
        understand = ai.get("understand", True)
        misspell = ai.get("misspell", [])

        # 记录 review
        conn.execute(
            "INSERT INTO reviews (word_id, review_date, result, last_input) VALUES (?,?,?,?)",
            (wid, t, verdict, user_input),
        )

        # 处理笔记本
        if verdict == "wrong" or understand is False:
            # 理解错误 -> 自动进理解笔记本
            conn.execute(
                "INSERT OR IGNORE INTO notebook (word_id, type) VALUES (?, 'understand')",
                (wid,),
            )
        # 拼写类由用户手动加，这里不自动处理

        results.append({
            "word_id": wid,
            "word": word_info["word"],
            "note": word_info["note"],
            "zh": word_info["zh"],
            "example": word_info["example"],
            "user_input": user_input,
            "verdict": verdict,
            "understand": understand,
            "misspell": misspell,
            "advice": ai.get("advice", ""),
        })

    conn.commit()
    conn.close()
    return jsonify({"results": results})


# AI 判定（DeepSeek）
def judge_with_ai(api_key, word_info, user_input):
    word = word_info["word"]
    note = word_info["note"]
    prompt = f"""你是学术英语词汇评判助手。请判断学生对单词的理解，并检查其英文释义中的拼写/表达问题。

【单词】{word}
【标准释义（参考答案，同义/英文解释）】{note}
【学生写的英文释义】{user_input}

请严格输出 JSON（不要输出其他内容），格式如下：
{{
  "understand": true/false,           // 学生是否理解了这个词的意思（语义正确）
  "misspell": ["拼写错误的词1", "词2"],  // 学生释义中拼写或表达有明显错误的词；若无则为空数组 []
  "advice": "给学生的准确/完整度建议（中文，简洁，1-2句）"
}}

判断标准：
- understand=true 表示学生的英文释义在语义上正确理解了这个词；理解偏了/错了则为 false。
- misspell 只列出真正拼错或表达明显错误的词；不影响理解的小瑕疵（如大小写、单复数）可不列。
- advice 用中文给出如何更准确或更完整的建议。"""
    try:
        resp = requests.post(
            "https://api.deepseek.com/chat/completions",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": "deepseek-chat",
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 0.2,
                "response_format": {"type": "json_object"},
            },
            timeout=30,
        )
        resp.raise_for_status()
        content = resp.json()["choices"][0]["message"]["content"]
        parsed = json.loads(content)
        understand = bool(parsed.get("understand", True))
        misspell = parsed.get("misspell", []) or []
        advice = parsed.get("advice", "")
        verdict = "correct" if understand else "wrong"
        return {"verdict": verdict, "understand": understand, "misspell": misspell, "advice": advice}
    except Exception as e:
        print("AI 判定失败，回退为 correct:", e)
        return {"verdict": "correct", "understand": True, "misspell": [], "advice": ""}


# ---------- 笔记本 ----------
@app.route("/api/notebook", methods=["GET"])
def api_notebook():
    conn = get_db()
    rows = conn.execute("""
        SELECT n.id as nb_id, n.type, n.added_at, w.word, w.note, w.zh, w.example, w.id as word_id
        FROM notebook n JOIN words w ON n.word_id = w.id
        ORDER BY n.added_at DESC
    """).fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])


@app.route("/api/notebook", methods=["POST"])
def api_notebook_add():
    """手动加词进笔记本（拼写本用）"""
    data = request.get_json()
    wid = data.get("word_id")
    ntype = data.get("type", "spelling")
    conn = get_db()
    conn.execute(
        "INSERT OR IGNORE INTO notebook (word_id, type) VALUES (?,?)", (wid, ntype)
    )
    conn.commit()
    conn.close()
    return jsonify({"ok": True})


@app.route("/api/notebook/<int:nb_id>", methods=["DELETE"])
def api_notebook_delete(nb_id):
    conn = get_db()
    conn.execute("DELETE FROM notebook WHERE id=?", (nb_id,))
    conn.commit()
    conn.close()
    return jsonify({"ok": True})


# ---------- 连续3天正确自动移出（在提交时检查） ----------
def auto_clean_notebook(conn):
    """检查所有笔记本中的词，若连续3个自然日都 correct，则移出"""
    rows = conn.execute("SELECT word_id, id FROM notebook").fetchall()
    for r in rows:
        wid = r["word_id"]
        nb_id = r["id"]
        # 取最近3天该词的 review 结果（按日期去重）
        recent = conn.execute("""
            SELECT review_date, result FROM reviews
            WHERE word_id=? ORDER BY review_date DESC LIMIT 6
        """, (wid,)).fetchall()
        # 按日期收集，最近3个不同自然日的结果都正确才移出
        seen_dates = {}
        for rev in recent:
            d = rev["review_date"]
            if d not in seen_dates:
                seen_dates[d] = rev["result"]
        dates = list(seen_dates.keys())  # 已按 DESC 排序
        ok_days = 0
        for d in dates:
            if seen_dates[d] == "correct":
                ok_days += 1
                if ok_days >= 3:
                    conn.execute("DELETE FROM notebook WHERE id=?", (nb_id,))
                    break
            else:
                break
    conn.commit()


# ---------- 课件上传 + 例句提取 ----------
@app.route("/api/upload", methods=["POST"])
def api_upload():
    if "file" not in request.files:
        return jsonify({"error": "无文件"}), 400
    f = request.files["file"]
    if f.filename == "":
        return jsonify({"error": "空文件名"}), 400
    safe_name = os.path.basename(f.filename)
    path = os.path.join(UPLOAD_DIR, safe_name)
    f.save(path)
    # 提取文本（简单支持 txt / 纯文本；PDF/Word 提取见后续）
    text = ""
    ext = safe_name.lower().rsplit(".", 1)[-1] if "." in safe_name else ""
    if ext == "txt":
        with open(path, "r", encoding="utf-8", errors="ignore") as fh:
            text = fh.read()
    else:
        text = "(该格式暂不支持自动提取例句，请上传 .txt 文本，或后续版本支持 PDF/Word)"
    return jsonify({"ok": True, "filename": safe_name, "text": text})


@app.route("/api/example/search", methods=["POST"])
def api_example_search():
    """在已上传文本中搜索包含某词的句子"""
    data = request.get_json()
    word = (data.get("word") or "").strip()
    text = (data.get("text") or "").strip()
    if not word or not text:
        return jsonify({"sentences": []})
    import re
    sentences = re.split(r'(?<=[.!?])\s+', text)
    hits = [s.strip() for s in sentences if word.lower() in s.lower()]
    return jsonify({"sentences": hits[:5]})


# ---------- 导出 ----------
@app.route("/api/export", methods=["GET"])
def api_export():
    conn = get_db()
    rows = conn.execute("SELECT word, note, zh FROM words ORDER BY word").fetchall()
    conn.close()
    lines = ["Keyword\tNotes"]
    for r in rows:
        note = r["note"] or ""
        zh = r["zh"] or ""
        if zh:
            note = note + ("  |  " + zh if note else zh)
        lines.append(f"{r['word']}\t{note}")
    content = "\n".join(lines)
    return content, 200, {
        "Content-Type": "text/plain; charset=utf-8",
        "Content-Disposition": "attachment; filename=vocab_export.txt",
    }


if __name__ == "__main__":
    init_db()
    app.run(host="127.0.0.1", port=5000, debug=False)
