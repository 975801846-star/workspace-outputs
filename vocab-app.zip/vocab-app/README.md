# 学术生词主动回忆小程序（本地网页版）

> 主动回忆式背词器。给英文单词 → 你打英文释义 → AI 判断对错。

## 快速启动

```bash
# 1. 进入目录
cd vocab-app

# 2. 安装依赖（首次）
pip install -r requirements.txt

# 3. 启动
python app.py
```

浏览器打开 `http://127.0.0.1:5000` 即可使用。

## 功能

- 录入单词（单词 + 备注 + 中文翻译）
- 背词：一页多词，左词右填释义，逐页提交
- AI 判定（DeepSeek）：理解 + 拼写两步，四档分类
- 两个笔记本：拼写笔记本（手动加）+ 理解笔记本（自动进）
- 连续 3 自然日答对自动移出笔记本
- 课件上传自动抓例句
- 导出「关键词 | 备注」两列表格

## 目录结构

```
vocab-app/
├── app.py            # Flask 后端主程序
├── requirements.txt  # 依赖
├── vocab.db          # SQLite 数据库（自动生成）
├── uploads/          # 上传的课件（自动生成）
├── static/           # 前端静态资源
│   ├── style.css
│   └── app.js
└── templates/
    └── index.html
```

## 注意

- 首次运行会在同目录生成 `vocab.db` 数据库文件，数据都在里面，备份它即可备份全部单词。
- AI 判定需要 DeepSeek API key，在 `config.json` 里配置（或首次使用时在界面填写）。
